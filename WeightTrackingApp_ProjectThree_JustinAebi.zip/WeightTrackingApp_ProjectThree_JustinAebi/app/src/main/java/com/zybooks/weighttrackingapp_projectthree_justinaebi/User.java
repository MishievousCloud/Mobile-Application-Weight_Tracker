package com.zybooks.weighttrackingapp_projectthree_justinaebi;

public class User {
    int id;
    String date, weight, goal;

    public User(int id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }


    public User(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
}
