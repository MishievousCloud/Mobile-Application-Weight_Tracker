package com.zybooks.weighttrackingapp_projectthree_justinaebi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etConfirmPassword;
    private Button btRegister;
    private TextView tvExitSignup;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        etUsername = (EditText)findViewById(R.id.et_username_reg);
        etPassword = (EditText)findViewById(R.id.et_password_reg);
        etConfirmPassword = (EditText)findViewById(R.id.et_confirmpassword_reg);
        btRegister = (Button)findViewById(R.id.bt_register);
        tvExitSignup = (TextView)findViewById(R.id.tv_exit_signup);
        DB = new DBHelper(this);

        // On click to register new user
        btRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // pull registration text fields as strings
                String user = etUsername.getText().toString();
                String pass = etPassword.getText().toString();
                String confirmpass = etConfirmPassword.getText().toString();

                // check if any fields are empty
                if (user.equals("") || pass.equals("") || confirmpass.equals("")) {
                    Toast.makeText(RegistrationActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // check is passwords match
                    if (pass.equals(confirmpass)) {
                        Boolean checkuser = DB.checkUsername(user);
                        // check if user already exists
                        if(checkuser == false) {
                            Boolean insert = DB.insertUserData(user, pass);
                            // successful registration
                            if (insert == true) {
                                Toast.makeText(RegistrationActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(RegistrationActivity.this, MainActivity.class));
                            } else {
                                Toast.makeText(RegistrationActivity.this, "Registration Failed",Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(RegistrationActivity.this, "User already exist", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(RegistrationActivity.this,"Password does not match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // exits the registration screen and returns to login screen
        tvExitSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationActivity.this, MainActivity.class));
            }
        });
    }
}