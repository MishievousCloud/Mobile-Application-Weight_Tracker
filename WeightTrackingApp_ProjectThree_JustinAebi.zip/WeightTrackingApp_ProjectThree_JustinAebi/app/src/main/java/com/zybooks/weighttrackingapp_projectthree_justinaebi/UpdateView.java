package com.zybooks.weighttrackingapp_projectthree_justinaebi;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateView extends AppCompatActivity {

    //Initialize Variables
    EditText updateGoal, updateDate, updateWeight, updateNewGoal, updateNewDate, updateNewWeight;
    Button btUpdate, btReturn;
    DBHelper DB;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_view);

        //Assign variables
        updateGoal = findViewById(R.id.updateGoal);
        updateDate = findViewById(R.id.updateDate);
        updateWeight = findViewById(R.id.updateWeight);
        updateNewGoal = findViewById(R.id.updateNewGoal);
        updateNewDate = findViewById(R.id.updateNewDate);
        updateNewWeight = findViewById(R.id.updateNewWeight);
        btUpdate= findViewById(R.id.bt_update);
        btReturn = findViewById(R.id.bt_returnToAddWeights);
        DB = new DBHelper(this);

        //TODO: Works to the point of reaching successful update, but does not actually update the database???
        //UPDATE: Successfully updated database but with zeros???
        //UPDATE: Now it no longer works??? Unknown error? (code 0 SQLITE_OK) Queries can be performed using SQLiteDatabase query or rawQuery methods only.
        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String oldGoal = updateGoal.getText().toString();
                String newGoal = updateNewGoal.getText().toString();
                String oldDate = updateDate.getText().toString();
                String newDate = updateNewDate.getText().toString();
                String oldWeight = updateWeight.getText().toString();
                String newWeight = updateNewWeight.getText().toString();

                //update goal if fields are entered
                if (!oldGoal.equals("") && !newGoal.equals("")) {
                    Boolean checkGoal = DB.checkGoal(oldGoal);
                    String id = DB.getGoalID(oldGoal);
                    if (checkGoal == true) {
                        DB.updateGoal(newGoal, oldGoal, id);
                        Toast.makeText(UpdateView.this, "Goal updated Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(UpdateView.this, "Goal does not exist", Toast.LENGTH_SHORT).show();
                    }
                }

                //update date if fields are entered
                if (!oldDate.equals("") && !newDate.equals("")) {
                    Boolean checkDate = DB.checkDate(oldDate);
                    String id = DB.getDateID(oldDate);
                    if (checkDate == true) {
                        DB.updateDate(newDate, oldDate, id);
                        Toast.makeText(UpdateView.this, "Date updated Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(UpdateView.this, "Date does not exist", Toast.LENGTH_SHORT).show();
                    }
                }

                //update weight if fields are entered
                if (!oldWeight.equals("") && !newWeight.equals("")) {
                    Boolean checkWeight = DB.checkWeight(oldWeight);
                    String id = DB.getWeightID(oldWeight);
                    if (checkWeight == true) {
                        DB.updateWeight(newWeight, oldWeight, id);
                        Toast.makeText(UpdateView.this, "Weight updated Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(UpdateView.this, "Weight does not exist", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //returns to add weight activity
        btReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UpdateView.this, AddWeights.class));
            }
        });

    }
}
