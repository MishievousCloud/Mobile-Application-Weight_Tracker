package com.zybooks.weighttrackingapp_projectthree_justinaebi;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    //Database name
    private static final String DBNAME = "Test2.db";
    //Database version
    private static final int DATABASE_VERSION = 2;
    //Database Table names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHTS = "userWeights";
    private static final String TABLE_GOAL = "userGoal";
    //Table columns
    public static final String ID = "id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String GOAL = "goal";
    public static final String DATE = "date";
    public static final String WEIGHT = "weight";

    private SQLiteDatabase sqLiteDatabase;

    public DBHelper(Context context) {
        super(context, DBNAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        // Creates a table for the users login info
        MyDB.execSQL("create Table users("+ ID +" INTEGER primary key autoincrement, "+ USERNAME +" TEXT, "+ PASSWORD +" TEXT)");
        MyDB.execSQL("create Table userWeights("+ ID +" INTEGER primary key autoincrement, "+ DATE +" TEXT, "+ WEIGHT +" TEXT)");
        MyDB.execSQL("create Table userGoal("+ ID +" INTEGER primary key autoincrement, "+ GOAL +" TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        //Drops tables on upgrade
        MyDB.execSQL("drop Table if exists "+ TABLE_USERS);
        MyDB.execSQL("drop Table if exists "+ TABLE_WEIGHTS);
        MyDB.execSQL("drop Table if exists "+ TABLE_GOAL);
        onCreate(MyDB);
    }

    //Inserts username and password into a table
    public Boolean insertUserData(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        //Create ContentValues
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME, username);
        contentValues.put(PASSWORD, password);
        //Insert data into table
        long result = MyDB.insert(TABLE_USERS, null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //Inserts date and weight into a table
    public Boolean insertWeightData(String date, String weight) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        //Create ContentValues
        ContentValues contentValues = new ContentValues();
        contentValues.put(DATE, date);
        contentValues.put(WEIGHT, weight);
        //Insert data into database
        long result = MyDB.insert(TABLE_WEIGHTS,null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //TODO: NOT IMPLEMENTED YET, NEED MORE TIME, was set to void for now.
    public void getGoalList(){
        ArrayList<User> arrayList = new ArrayList<>();
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from userGoal", null);
    }

    //Populates list view with user entered dates and corresponding weights
    public ArrayList<User> getWeightList(){
        ArrayList<User> arrayList = new ArrayList<>();
        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery("Select *  from userWeights", null);

        //Iterate through the array list
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            String weight = cursor.getString(2);
            User user = new User(id,date,weight);
            arrayList.add(user);
        }
        return arrayList;
    }

    //Inserts goal into a table for the user
    public Boolean insertGoalData(String goal) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        //Create ContentValues
        ContentValues contentValues = new ContentValues();
        contentValues.put(GOAL, goal);
        //Insert data into database
        long result = MyDB.insert(TABLE_GOAL,null,contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //Checks if username is already used
    public Boolean checkUsername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //Checks if username and password exists in the table
    public Boolean checkUsernamePassword(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?",new String[] {username, password});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //Checks if goal exists in table
    public Boolean checkGoal(String goal) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from userGoal where "+ GOAL +" = ?", new String[] {goal});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //Checks if date exists in table
    public Boolean checkDate(String date) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from userWeights where "+ DATE +" = ?", new String[] {date});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //Checks if weight exists in table
    public Boolean checkWeight(String weight) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from userWeights where "+ WEIGHT +" = ?", new String[] {weight});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //updates date to new date value
    public void updateDate(String newDate, String oldDate, String getID){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Update userWeights set "+ DATE +" = "+ newDate +" where "+ DATE +" = "+ oldDate +" and "+ ID +" = "+ getID;
        MyDB.execSQL(query);
    }

    //updates weight to new weight value
    public void updateWeight(String newWeight, String oldWeight, String getID){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Update userWeights set "+ WEIGHT +" = "+ newWeight +" where "+ WEIGHT +" = "+ oldWeight +" and "+ ID +" = "+ getID;
        MyDB.execSQL(query);
    }

    //updates goal to new goal value
    public void updateGoal(String newGoal, String oldGoal, String getID){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Update userGoal set "+ GOAL +" = "+ newGoal +" where "+ GOAL +" = "+ oldGoal +" and "+ ID +" = "+ getID;
        MyDB.execSQL(query);
    }

    //Pull ID from table where data matches
    public String getGoalID(String getGoal){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Select "+ ID +" from userGoal where "+ GOAL +" = "+ getGoal;
        MyDB.execSQL(query);
        return ID;
    }

    // Pull ID from table where data matches
    public String getDateID(String getDate){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Select "+ ID +" from userWeights where "+ DATE +" = "+ getDate;
        MyDB.execSQL(query);
        return ID;
    }

    //Pull ID from table where data matches
    public String getWeightID(String getWeight){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Select "+ ID +" from userWeights where "+ WEIGHT +" = "+ getWeight;
        MyDB.execSQL(query);
        return ID;
    }

    //Delete date method
    public void deleteDate(String oldDate){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Delete from userWeights where "+ DATE +" = "+ oldDate;
        MyDB.execSQL(query);
    }

    //Delete weight method
    public void deleteWeight(String oldWeight){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Delete from userWeights where "+ WEIGHT +" = "+ oldWeight;
        MyDB.execSQL(query);
    }

    //Delete goal method
    public void deleteGoal(String oldGoal){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String query = "Delete from userGoal where "+ GOAL +" = "+ oldGoal;
        MyDB.execSQL(query);
    }
}

