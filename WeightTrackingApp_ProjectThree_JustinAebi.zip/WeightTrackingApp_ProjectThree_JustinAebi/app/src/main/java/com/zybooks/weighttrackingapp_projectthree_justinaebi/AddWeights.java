package com.zybooks.weighttrackingapp_projectthree_justinaebi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddWeights extends AppCompatActivity {

    //Initialized Variables
    private EditText etGoal, etDate, etWeight;
    private Button btAdd, btAddGoal, btViewWeight, btUpdate, btDelete;
    private TextView tvGoal;
    DBHelper DB;
    DrawerLayout drawerLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weights);

        //Assigned Variables
        drawerLayout = findViewById(R.id.drawer_layout);
        etGoal = (EditText) findViewById(R.id.et_goal);
        etDate = (EditText) findViewById(R.id.et_date);
        etWeight = (EditText) findViewById(R.id.et_weight);
        tvGoal = (TextView) findViewById(R.id.tv_goal);
        btAdd = (Button) findViewById(R.id.bt_addWeightDetails);
        btAddGoal = (Button) findViewById(R.id.bt_addGoal);
        btUpdate = (Button) findViewById(R.id.bt_update);
        btDelete = (Button) findViewById(R.id.bt_deleteWeight);
        btViewWeight = (Button) findViewById(R.id.bt_viewWeight);
        DB = new DBHelper(this);

        //Listener for Add button to insert data
        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = etDate.getText().toString();
                String weight = etWeight.getText().toString();

                if (date.equals("") || weight.equals("")){
                    //If either field is empty
                    Toast.makeText(AddWeights.this, "Please enter a date and weight", Toast.LENGTH_SHORT).show();
                } else {
                    //Add weight and date
                    Boolean insert = DB.insertWeightData(date, weight);
                    if (insert == true){
                        Toast.makeText(AddWeights.this,"Weight entered successfully",Toast.LENGTH_SHORT).show();
                        etDate.setText("");
                        etWeight.setText("");
                    } else {
                        Toast.makeText(AddWeights.this, "Failed to enter weight",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //Listener for Add Goal button to insert data //NOTE: Kept separate from btAdd in case user does not want to enter goal
        btAddGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goal = etGoal.getText().toString();

                if (goal.equals("")){
                    //If either field is empty
                    Toast.makeText(AddWeights.this, "Please enter a goal", Toast.LENGTH_SHORT).show();
                }else {
                    //If not empty add goal weight
                    DB.insertGoalData(goal);
                    Toast.makeText(AddWeights.this, "Goal weight entered successfully", Toast.LENGTH_SHORT).show();
                    etGoal.setText("");
                }
            }
        });

        //Listener for view weight button to bring back to home activity where weight list is located
        btViewWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddWeights.this, HomeActivity.class));
            }
        });

        //TODO: Update works, however the fields are not changed???
        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddWeights.this, UpdateView.class));
            }
        });

        //Listener for delete button to delete fields from the database
        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //If the user enters goal
                if (!etGoal.equals("")) {
                    String goal = etGoal.getText().toString();
                    Boolean checkGoal = DB.checkGoal(goal);
                    if (checkGoal == true) {
                        DB.deleteGoal(goal);
                        etGoal.setText("");
                        Toast.makeText(AddWeights.this, "Successfully deleted goal weight", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddWeights.this, "No such goal exists in the database", Toast.LENGTH_SHORT).show();
                    }
                } 
                
                //If the user enters a date
                if (!etDate.equals("")) {
                    String date = etDate.getText().toString();
                    Boolean checkDate = DB.checkDate(date);
                    if (checkDate == true) {
                        DB.deleteDate(date);
                        etDate.setText("");
                        Toast.makeText(AddWeights.this, "Successfully deleted date", Toast.LENGTH_SHORT).show();
                    } else{
                        Toast.makeText(AddWeights.this, "No such date exists in the database", Toast.LENGTH_SHORT).show();
                    }
                }

                //If the user enters a weight
                if (!etWeight.equals("")) {
                    String weight = etWeight.getText().toString();
                    Boolean checkWeight = DB.checkWeight(weight);
                    if (checkWeight == true) {
                        DB.deleteWeight(weight);
                        etWeight.setText("");
                        Toast.makeText(AddWeights.this, "Successfully deleted weight", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddWeights.this, "No such weight exists in the database", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void ClickMenu(View view){
        //Open drawer
        HomeActivity.openDrawer(drawerLayout);
    }

    public void ClickLogo(View view){
        //Close drawer
        HomeActivity.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        //Redirect activity to home
        HomeActivity.redirectActivity(this, HomeActivity.class);
    }

    public void ClickNotifications(View view){
        //Recreate activity
        HomeActivity.redirectActivity(this, Notifications.class);
    }

    public void ClickLogout(View view){
        //Close app
        HomeActivity.logout(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //Close drawer
        HomeActivity.closeDrawer(drawerLayout);
    }
}