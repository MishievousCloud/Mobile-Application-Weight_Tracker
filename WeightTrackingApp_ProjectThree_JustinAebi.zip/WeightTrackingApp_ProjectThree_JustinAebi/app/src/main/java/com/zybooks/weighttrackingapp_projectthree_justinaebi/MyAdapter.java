package com.zybooks.weighttrackingapp_projectthree_justinaebi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {

    Context context;
    ArrayList<User> arrayList;


    public MyAdapter(Context context, ArrayList<User> arrayList){
        this.context = context;
        this.arrayList = arrayList;
    }


    @Override
    public int getCount() {
        return this.arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //inflate view with custom list view
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.list_item, null);
        TextView itemDate = (TextView)convertView.findViewById(R.id.item_date);
        TextView itemWeight = (TextView)convertView.findViewById(R.id.item_weight);

        User user = arrayList.get(position);

        //Set text views to user inputs for data and weight
        itemDate.setText(user.getDate());
        itemWeight.setText(user.getWeight());
        return convertView;
    }
}
